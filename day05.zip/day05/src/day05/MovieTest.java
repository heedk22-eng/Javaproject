package day05;
import java.util.*;
public class MovieTest {

	public static void main(String[] args) {
		
		// movie 객체 생성
		Movie m1 = new Movie();
		Movie m2 = new Movie();
		
		Scanner scan = new Scanner(System.in);
		Movie m3;
		Movie [] maray = new Movie[2];
		
		for(int i=0; i<maray.length; i++) {
			System.out.print("영화 제목: ");
			String title = scan.nextLine();
			System.out.print("영화 감독: ");
			String direc = scan.nextLine();
			m3 = new Movie(title, direc);		    
		    maray[i] = m3;
		}
		for(int i=0; i<maray.length; i++) {
			System.out.print("{" + maray[i].title + "," + maray[i].director + "}");		
			
		}

	}

}
