package day05;
import javax.swing.JFrame;

public class MyJFrame {

	public static void main(String[] args) {
		
		for(int i = 1; i<=10; i++) {
			JFrame jf = new JFrame();
			jf.setSize(300, 300);
			jf.setVisible(true);
			jf.setTitle("나만의 프레임 제목" + i);
		}
	}
}
