package day05;
import java.util.*;
public class Dice {
	
	// 필드
	int i;
	
	// 기본 생성자
	public Dice() {}
	
	// 인자 생성자
	public Dice(Random rand) {
		int num = rand.nextInt(6)+1;   // 1이상 7미만
		i = num;
	}
	
	// 랜덤하게 숫자 만드는 makeNum() 메소드 생성
	
	
}
