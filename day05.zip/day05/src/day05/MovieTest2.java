package day05;
import java.util.*;
public class MovieTest2 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		// 동적 배열 저장 할 ArrayList객체 생성
	    ArrayList<Movie> alist = new ArrayList<Movie>();
		
		System.out.print("영화 제목: ");
		String title = scan.nextLine();
		System.out.print("영화 감독: ");
		String direc = scan.nextLine();
		
		alist.add(new Movie(title, direc));
		// Movie m = new Movie(title, direc);
		// alist.add(m)
		
		for(Movie m1: alist) {
			System.out.print("{" + m1.title + ", " + m1.director + "}");		
			
		}

	}

}
