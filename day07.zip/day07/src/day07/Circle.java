package day07;

public class Circle extends Shape implements Printable{
	
	@Override
	void draw() {
		System.out.println("원 도형을 그립니다.");
		
	}
	
	@Override
	public void print() {
		System.out.println("프린터로 원을 출력합니다.");
		
	}
}
