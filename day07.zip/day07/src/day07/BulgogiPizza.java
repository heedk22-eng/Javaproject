package day07;

public class BulgogiPizza extends Pizza{
	
	@Override
	void make() {
		System.out.println("불고기 피자를 만든다.");
	}

}
