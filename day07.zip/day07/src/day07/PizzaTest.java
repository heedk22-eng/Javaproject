package day07;

public class PizzaTest {
	//static Pizza[] pizzas;
	
	static void pizzaMake(Pizza pizza) {   // 다형성
		pizza.make();
		
	}
	
	public static void main(String[] args) {
		// 다형성구현
		//Pizza[] pizzas = new Pizza[2];
		//pizzas[0] = new CheezePizza();
		//pizzas[1] = new BulgogiPizza();
		
		CheezePizza cpizza = new CheezePizza();
		BulgogiPizza bulpizza = new BulgogiPizza();
		
		PizzaTest.pizzaMake(cpizza);
		PizzaTest.pizzaMake(bulpizza);
		
	}
}
