package day07;

public abstract class Shape {
	
	// 추상메소드
	
	abstract void draw();

}
