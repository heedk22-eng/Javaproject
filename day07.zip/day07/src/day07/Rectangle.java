package day07;

public class Rectangle extends Shape{
	
	@Override
	void draw() {
		System.out.println("사각형 도형을 그립니다.");
		
	}

}
