package day07;

public class Pizza {
	
	void make() {
		System.out.println("피자를 만든다.");
	}

}
