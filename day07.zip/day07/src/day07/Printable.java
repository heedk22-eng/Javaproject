package day07;

public interface Printable {   // 상수와 추상메소드를 멤버로 갖는다.
	
	void print();

}
