package day07;

public class CheezePizza extends Pizza{
	
	@Override
	void make() {
		System.out.println("치즈 피자를 만든다.");
	}

}
