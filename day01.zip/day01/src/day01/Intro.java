package day01;

public class Intro {

	public static void main(String[] args) {
		System.out.println("안녕하세요?");
		System.out.println("저는 자바를 처음 공부합니다");
		System.out.println("저의 나이는 24살이고 이름은 김대희입니다");

	}

}
