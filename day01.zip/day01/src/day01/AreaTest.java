package day01;
import java.util.*;
public class AreaTest {

	public static void main(String[] args) {
		final double PI = 3.141592;
		double radius, area;
		
		//radius = 7.0;
		//area = PI*radius*radius;
		//System.out.println("반지름이 5인 원의 면적은 "+ area);
		Scanner scan = new Scanner(System.in);
		
		radius = scan.nextDouble();
		area = 3.141592 * radius * radius;
		System.out.println(area);
	}

}
