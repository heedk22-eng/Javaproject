package day01;

public class Code01_01 {

	public static void main(String[] args) {
		// 한줄 주석 표현
		System.out.print("Hello World~~\"아이오\"");
		System.out.print("Hello Java~~");

	}

}
