package day06;

public class Teacher extends Person{   // 상속하기(Person)
	
	String tid;   // 교번
	
	// 메소드 오버라이딩
	public void showInfo() {
		super.showInfo();
		System.out.println(" 교번: " + tid);
	}
	
}
