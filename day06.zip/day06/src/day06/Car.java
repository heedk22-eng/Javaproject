package day06;

public class Car extends Vehicle{

	@Override
	void setSpeed(int speed) {
		
		System.out.println(speed + "로 설정하고 달린다.");
		
	}   // 상속 구현
	
}
