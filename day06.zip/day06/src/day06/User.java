package day06;

public class User {  // 사용자
	String id, pwd;
	
	// 기본생성자
	public User() {
		
	}
	
	// 인자생성자
	public User(String id, String pwd) {
		this.id = id;
		this.pwd = pwd;
		
	}
	// id, pwd 모두 출력하는 메소드 생성
	public void showUser() {
		System.out.println("ID: " + id);
		System.out.println("PWD: " + pwd);
	
	}

}
