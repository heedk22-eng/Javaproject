package day06;

public abstract class Vehicle {   // 부모 클래스(타는 것)
	
	int speed;
	
	// 추상 메소드
	abstract void setSpeed(int speed);
	
	void turn() {
		System.out.println("회전한다");
	}

}
