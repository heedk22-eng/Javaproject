package day06;

public class Staff extends Person{
	
	String sfid;   // 사번
	
	// 메소드 오버라이딩
	public void showInfo() {
		super.showInfo();
		System.out.println(" 사번: " + sfid);
	}

}
