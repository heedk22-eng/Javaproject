package day13;

public class MemberDTO {
	// 회원 객체가 갖는 속성
	private int id;
	private String username;
	private String dept;
	private String birth;
	private String email;
	
    // 인자 생성자
	public MemberDTO(int id, String username, String dept, String birth, String email) {
		this.id = id;
		this.username = username;
		this.dept = dept;
		this.birth = birth;
		this.email =email;
	}
	// 인자 생성자
	public MemberDTO(int id, String username, String dept, String email) {
		this.id = id;
		this.username = username;
		this.dept = dept;
		this.email =email;
		}
	
	// 기본 생성자
	public MemberDTO() {
		
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public String getBirth() {
		return birth;
	}
	public void setBirth(String birth) {
		this.birth = birth;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

}
