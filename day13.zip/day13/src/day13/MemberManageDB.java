package day13;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class MemberManageDB {
	

	public static void main(String[] args) {
		
		String url = "jdbc:mysql://localhost:3306/mydb";
		String id = "root";
		String pwd = "1234";
		
		// 1. JDBC 드라이버 로딩
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
		// 2. 데이터베이스 연결
			try {
				Connection con = DriverManager.getConnection(url, id, pwd);
				
		// 3. 데이터 조작 (statement 객체 생성)
				String sql = "INSERT INTO member (id, username, dept, email) values(?, ?, ?, ?);";
				PreparedStatement psmt = con.prepareStatement(sql);
				psmt.setInt(1, 2013111);
				psmt.setString(2, "김대희");
				psmt.setString(3, "정보통신공학과");
				psmt.setString(4, "kdh@dju.kr");
				
		// 4. statement 전송하기   5. 결과 받기
		// 입력, 수정, 삭제 전송 -> executeUpdate() 결과는 (실패시 0과 같은 정수로 반환됨)
				
				int result = psmt.executeUpdate();
				if (result !=0) System.out.println("입력 성공~");
				else System.out.println("입력 실패~");
				
		// 6. 연결 해제
				con.close();
				
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		}

	}

}
