package day13;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class MemberDAO {
	
	Connection con;
	PreparedStatement pt;
	ResultSet rs;
	
	public MemberDAO() {
		String url = "jdbc:mysql://localhost:3306/mydb";
		String id = "root";
		String pwd = "1234";
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			try {
				con = DriverManager.getConnection(url, id, pwd);
				
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		}
		
	}// 생성자------------------------------------------------
	
	// 1. 데이터 추가 메소드 (insertDB())
	public int insertDB(MemberDTO mdto) {
		String sql = "INSERT INTO member (id, username, dept, email) values(?, ?, ?, ?);";
		int result = -1;
		
		try {
		pt = con.prepareStatement(sql);
		pt.setInt(1, mdto.getId());
		pt.setString(2, mdto.getUsername());
		pt.setString(3, mdto.getDept());
		pt.setString(4, mdto.getEmail());
		result = pt.executeUpdate();
		
		}catch(SQLException e) {
			e.printStackTrace();
		}
		if(result !=0) 
			return 1;
		else
			return 0;
		
		}
	
	
	// 2. 데이터 모두 조회 메소드 (selectAll())
	public ArrayList<MemberDTO> selectAll(){
		ArrayList<MemberDTO> alist = new ArrayList<MemberDTO>();
		String sql = "SELECT * FROM member";
		int result = -1;
		
		try {
		pt = con.prepareStatement(sql);
		rs = pt.executeQuery();
		
		while(rs.next()) {
			int rid = rs.getInt("id");
			 String udpt = rs.getString("dept");
			 String uemail = rs.getString("email");
			 String uname = rs.getString("username");
			 java.sql.Date d = rs.getDate("birth");
			 String da = d + "";
			 ////////////////////////////////////////////////////////////
			 MemberDTO m = new MemberDTO(rid, uname, udpt, da, uemail);
			 ////////////////////////////////////////////////////////////
			 alist.add(m);
		 }
		
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return alist;
	}

	
	// 3. 데이터 수정 메소드 (updateDB())
	
	// 4. 데이터 삭제 메소드 (deleteDB())

}
