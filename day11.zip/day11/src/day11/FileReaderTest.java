package day11;

import java.io.*;

public class FileReaderTest {

	public static void main(String[] args) {
		// 1.데이터 소스(근원지) / 예) 파일, 하드디스크, 원격지컴퓨터
		
		// 2.데이터 목적지 / 예) 파일, 디스크, 모니터, 원격지컴퓨터
		
		// 3.데이터의 종류 - 1바이트 데이터 xxxInputStream, xxxOutputStream
		//                 - 2바이트 데이터 xxxReader, xxxWriter객체
		
		try {
			FileReader fileReader = new FileReader("test.txt");
			try {
				int data = 0;
				while(data !=-1) {
					
				     data = fileReader.read();
				     System.out.println((char)data);
				}
				
				fileReader.close();
				
			} catch (IOException e) {
				
				e.printStackTrace();
			}
			
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
		
	}

}
