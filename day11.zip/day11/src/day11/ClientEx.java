package day11;

import java.io.*;
import java.net.*;
import java.util.*;

public class ClientEx {

	Socket sock;
	BufferedWriter bw;
	BufferedReader br;

	public ClientEx() {
		try {
			sock = new Socket("172.17.201.123", 8888);
			System.out.println("서버 연결 성공~~~");
			Scanner scanner = new Scanner(System.in);
			br = new BufferedReader(new InputStreamReader(sock.getInputStream()));
			bw = new BufferedWriter(new OutputStreamWriter(sock.getOutputStream()));

			while (true) {
				System.out.print("보내기>>"); // 프롬프트
				String outputMessage = scanner.nextLine(); // 키보드에서 한 행 읽기
				if (outputMessage.equalsIgnoreCase("bye")) {
					bw.write(outputMessage + "\n"); // "bye" 문자열 전송
					bw.flush();
					break; // 사용자가 "bye"를 입력한 경우 서버로 전송 후 실행 종료
				}
				bw.write(outputMessage + "\n"); // 키보드에서 읽은 문자열 전송
				bw.flush(); // out의 스트림 버퍼에 있는 모든 문자열 전송
				String inputMessage = br.readLine(); // 서버로부터 한 행 수신
				System.out.println("서버: " + inputMessage);
			}

		} catch (UnknownHostException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}

	}

	public static void main(String[] args) {
		new ClientEx();

	}

}
