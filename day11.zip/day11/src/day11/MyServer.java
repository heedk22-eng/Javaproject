package day11;
import java.io.*;
import java.net.*;
public class MyServer {

	ServerSocket  ser;
	Socket sock;
	BufferedWriter bw;
	
	public MyServer() {
		try {
			ser = new ServerSocket(9999);
			System.out.println("대기중~~~");
			sock = ser.accept();
			System.out.println("클라이언트와 연결 성공~~~");
			
			bw = new BufferedWriter(new OutputStreamWriter(sock.getOutputStream()));
			bw.write("반갑습니다.");
			bw.flush();
			
			bw.close();
			sock.close();
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		
		new MyServer();

	}

}
