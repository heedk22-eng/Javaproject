package day11;
import java.io.*;
public class CopyFile2 {

	public static void main(String[] args) {
		try {
			FileInputStream fis = new FileInputStream("a.jpg");
			FileOutputStream fos = new FileOutputStream("b.jpg");
			
			int c;
			while((c = fis.read())!=-1) {
				fos.write(c);
				
			}
			
			fis.close();
			fos.close();
			
		}catch(Exception e) {
			e.printStackTrace();
		
		}
	}

}
