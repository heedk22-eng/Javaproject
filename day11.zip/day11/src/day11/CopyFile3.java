package day11;
import java.io.*;
public class CopyFile3 {

	public static void main(String[] args) {
		try {
			FileReader fr = new FileReader("test2.txt");
			BufferedReader br = new BufferedReader(fr);
			
			PrintWriter pw = new PrintWriter(System.out);
			
			
			String data;
			
			while((data = br.readLine())!=null) {
				pw.write(data);
				pw.flush();
				
			}
			
			fr.close();
			br.close();
			pw.close();
			
		}catch(Exception e) {
			e.printStackTrace();
		
		}
	}

}
