package my;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

public class MyFrame2 extends JFrame{
	
	public MyFrame2() {
		// 1.super("My Frame");
		setSize(300,200);
		getContentPane().setBackground(Color.YELLOW);
		setLocation(200, 300);
		
		// 2.레이아웃(배치 설정하기)
		setLayout(new BorderLayout());
		
		// 3.컴포넌트 생성하기
		JButton btn1 = new JButton("동");
		JButton btn2 = new JButton("서");
		JButton btn3 = new JButton("남");
		JButton btn4 = new JButton("북");
		JButton btn5 = new JButton("가운데");
		
		// 4.컴포넌트 컨테이너 붙이기
		add(btn1, BorderLayout.EAST);
		add(btn2, BorderLayout.WEST);
		add(btn3, BorderLayout.SOUTH);
		add(btn4, BorderLayout.NORTH);
		add(btn5, BorderLayout.CENTER);
		
		setVisible(true);
		setTitle("-----BorderLayout-----");
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
	}

	public static void main(String[] args) {
		
		MyFrame2 mf = new MyFrame2();
		

	}

}
