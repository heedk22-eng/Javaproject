package my;

public class StringTest {

	public static void main(String[] args) {
		
		String s1 = new String("자바");
		String s2 = new String("자바");
		
		if(s1.equals(s2)) {
			System.out.println("동일한 문자열입니다.");
		}else {
				System.out.println("동일한 문자열이 아닙니다.");
		}
		
		if(s1 == s2) {    // 힙 메모리 주소 비교
			System.out.println("동일한 문자열 입니다.");
			System.out.println(s1);
			System.out.println(s2);
		}else {
				System.out.println("동일한 문자열이 아닙니다.");
				System.out.println(s1);
				System.out.println(s2);
		}	
		
	}
}


