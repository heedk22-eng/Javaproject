package my;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

public class TryTest {

	public static void main(String[] args) {
		
		
		try {
			InputStreamReader fr = new InputStreamReader(new FileInputStream("test.txt"));
			BufferedReader bf = new BufferedReader(fr);
			String data = "";
			
			while((data = bf.readLine())!= null) {
				System.out.println(data);
			}
			
		}catch(Exception e) {
			//System.out.println("파일을 찾을 수 없습니다.");
			e.printStackTrace();
		}

	}

}
