package my;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.LayoutManager;

import javax.swing.JButton;
import javax.swing.JFrame;

public class MyFrame extends JFrame{
	
	public MyFrame() {
		// 1.super("My Frame");
		setSize(300,200);
		getContentPane().setBackground(Color.YELLOW);
		setLocation(200, 300);
		// 2.레이아웃(배치 설정하기)
		LayoutManager lm = getLayout();
		System.out.println(lm);
		//setLayout(new FlowLayout());
		// 3.컴포넌트 생성하기
		JButton btn = new JButton("확인");
		JButton btn2 = new JButton("취소");
		// 4.컴포넌트 컨테이너 붙이기
		add(btn);
		add(btn2);
		setVisible(true);
		setTitle("-----MyFrame-----");
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
	}

	public static void main(String[] args) {
		
		MyFrame mf = new MyFrame();
		

	}

}
