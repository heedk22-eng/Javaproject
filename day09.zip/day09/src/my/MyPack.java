package my;

class Circle{
	// 속성
	int radius;
	
	// 인자 생성자
	public Circle(int radius) {
		this.radius = radius;
	}
	
	// 메소드
	public String toString() {
		return "Circle(반지름이 " + radius + "인 원입니다.)";
	}
	
}

public class MyPack {

	public static void main(String[] args) {
		
		Circle c1 = new Circle(5);
		System.out.println(c1.toString());

	}

}
