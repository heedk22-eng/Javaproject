package day04;

class Account{
	// 필드 은닉화 + 추상화
	private String regaccount;   // 계좌번호
	private String name;      // 계좌주인 이름
	private int balance;      // 계좌 잔액
	
	// 기본 생성자
	public  Account(){
		
	}
	
	// 인자 생성자
	public Account(String reg, String name, int balance) {
		regaccount = reg;
		this.name = name;
		this.balance = balance;
	}
	
	// 입금 메소드
	public int deposit(int money) {
		balance += money;   // balance = balance + money
		return balance;
	}
	
	// 출금 메소드
	public int withdarw(int money) {
		balance -= money;   // balance = balance - money
		return balance;
	}	
	
	// setter 메소드(설정자)
	public void setRegaccount(String reg) {
		regaccount = reg;
	}
	public void setName(String name) {
		this.name = name;
	}
		public void setBalance(int balance) {
		this.balance = balance;
	}
	
	// getter 메소드(접근자)
	public String getRegaccount() {
		return regaccount;
	}
	public String getName() {
		return name;
	}
	public int getBalance() {
		return balance;
	}
	
}

public class AccountTest {
	

	public static void main(String[] args) {
		
		Account hana = new Account("123-456-789", "홍길동", 10000);
		Account kb = new Account("456-789-1122", "이길동", 1000);
		
		int balance = kb.deposit(1000);
		System.out.println("kb 계좌 잔액: " + balance);
		System.out.println("kb 계좌 출금 후 잔액: " + kb.withdarw(1500));
		
		System.out.println(hana.getRegaccount());
		System.out.println(hana.getName());
		System.out.println(hana.getBalance());
		
		hana.setBalance(1000);
		System.out.println(hana.getBalance());

	}

}
