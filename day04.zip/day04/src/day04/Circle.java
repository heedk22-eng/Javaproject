package day04;

// 1. 추상화
public class Circle {

	// 필드 == 속성 == 상태 == 멤버 변수
	String color;
	double radius;
	
	// 기본 생성자
	public Circle() {
		this(0.0);
	}
	
	
	// 인자 생성자
	public Circle(double r) {
		radius = r;
	}
	
	
	// 메소드
	double printArea() {
		return radius * radius * 3.14;
		
	}
	// 매개변수 1개 받아서 radius 변수 초기화
	void setRadius(double ra) {
		radius = ra;
		
	}

}
