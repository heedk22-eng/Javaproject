package day04;


class Pizza {
	
	int size;
	String type;
	
	// 기본 생성자...: 반환형은 명시 하지 않는다. 이름은 클래스이름과 같다.
	public Pizza() {
		size = 12;
		type = "슈퍼슈프림";
	}
	
	// 인자 생성자...
	public Pizza(int size, String type) {
		this.size = size;
		this.type = type;
	}

}

public class PizzaHut {

	public static void main(String[] args) {
		
		Pizza pizza = new Pizza();
		Pizza pizza1 = new Pizza();
		Pizza pizza2 = new Pizza(10, "페퍼로니 피자");
		//pizza.type = "불고기 피자";
		//pizza.size = 12;
		pizza1.type = "불고기 피자";
		pizza1.size = 5;	
		
		
		System.out.println(pizza.type + pizza.size);
		System.out.println(pizza1.type + pizza1.size);
		System.out.println(pizza2.type + pizza2.size);

	}

}
