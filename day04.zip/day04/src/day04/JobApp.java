package day04;

import java.util.ArrayList;

public class JobApp {

	public static void main(String[] args) {
		
		Person person1 = new Person("김미남", "남자", 30);
		Person person2 = new Person("이미녀", "여자", 25);
		Person person3 = new Person();
		//person3.name = "박아무개";
		person3.setName("박아무개");
		System.out.println(person3.getName());
		
		ArrayList<Person> alist = new ArrayList<>();
		
		alist.add(person1);
		alist.add(person2);
		
		for(Person p : alist) {
			
			p.personInfo();
		}
		
		//person1.yourName("홍길동");
		//System.out.println(person1.yourAge(10));
		
		person1.personInfo("홍길동");
		

	}

}
