package day12;

public class TestThread {

	public static void main(String[] args) {
		// 스레드 2개  생성하기

		Thread thread1 = new Thread(new MyRunnable("A"));
		Thread thread2 = new Thread(new MyRunnable("B"));
		
		try {
			
				thread1.start();
				thread2.start();
			
		}catch (Exception e) {
			e.printStackTrace();
		}

	}

}
