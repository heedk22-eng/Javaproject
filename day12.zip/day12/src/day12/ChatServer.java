package day12;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;

public class ChatServer extends JFrame implements ActionListener, Runnable {
	
	JTextField enter;
	JTextArea display;
	PrintWriter output;
	BufferedReader input;
	String message = "";
	
	ArrayList<Socket> alist = new ArrayList<Socket>();
	
	//ServerSocket ser;
	//Socket ssock;

	public ChatServer() {
		
		setTitle("---ChatServer ver1.0---");
		
		enter = new JTextField();
		enter.setEnabled(false);
		add(enter, BorderLayout.NORTH);
		display = new JTextArea();
		add(new JScrollPane(display), BorderLayout.CENTER);
		//////////////////////////////////////////////////////////////////
		enter.addActionListener(this);
		
		setSize(300, 150);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
	}
	
	
	public static void main(String[] args) {
		ChatServer cs = new ChatServer();
		Thread t1 = new Thread(cs);
		t1.start();

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		message = e.getActionCommand();
		output.println("서버 >>> " + message);
		display.append("\n서버 >>> " + message);
		enter.setText("");
		if(message.contains("잘 있어"))
		   System.exit(0);
		
	}
	

	@Override
	public void run() {
		
		try {
			ServerSocket ser = new ServerSocket(7777);
			while(true) {
				display.append("연결 대기중...\n");
				display.setCaretPosition(display.getText().length());
				Socket ssock = ser.accept();
				////////////////////////////
				alist.add(ssock);
				////////////////////////////
				display.append(ssock.getInetAddress().getHostName() + "와 연결");
				
				output = new PrintWriter(ssock.getOutputStream(), true);
				input = new BufferedReader(new InputStreamReader(ssock.getInputStream()));
				enter.setEnabled(true);
				
				do {
					try {
						message = input.readLine();
						display.append("\n" + message);
						display.setCaretPosition(display.getText().length());
				  }  catch(Exception e) {
				  }
				}while (!message.contains("잘 있어"));
				
				display.append("\n사용자가 연결 종료\n");
				display.setCaretPosition(display.getText().length());
				enter.setEnabled(false);
				output.close();
				input.close();
				ssock.close();
				
			}// while()------------------------------------------
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
		
	}

}//////////////////////////////////////////////////////////////////////////
