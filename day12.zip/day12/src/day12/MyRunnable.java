package day12;

public class MyRunnable implements Runnable{
	
	String name;
	
	public MyRunnable(String name) {
		this.name = name;
	}

	@Override
	public void run() {
		for(int i=10; i>=0; i--) {
			System.out.print(name + i + " ");
		}
		
	}

}
