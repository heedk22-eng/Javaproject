package day12;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;

public class ChatClient extends JFrame implements ActionListener, Runnable {

	JTextField enter;
	JTextArea display;
	PrintWriter output;
	BufferedReader input;
	String message = "";

	Socket csock;

	public ChatClient() {

		setTitle("---ChatClient ver1.0---");

		enter = new JTextField();
		enter.setEnabled(false);
		add(enter, BorderLayout.NORTH);
		display = new JTextArea();
		add(new JScrollPane(display), BorderLayout.CENTER);
		//////////////////////////////////////////////////////////////////
		enter.addActionListener(this);

		setSize(300, 150);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);

	}

	public static void main(String[] args) {
		ChatClient ct = new ChatClient();
		Thread t2 = new Thread(ct);
		t2.start();

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		message = e.getActionCommand();
		output.println("클라이언트 >>> " + message);
		display.append("\n클라이언트 >>> " + message);
		enter.setText("");
		if (message.contains("잘 있어"))
		System.exit((0));

	}

	@Override
	public void run() {
		
		try {
			display.setText("연결 시도\n");
			display.setCaretPosition(display.getText().length());
			csock = new Socket("localhost",7777);
			System.out.println("연결 성공");
		    display.append(csock.getInetAddress().getHostName() + "와 연결");
			
			output = new PrintWriter(csock.getOutputStream(), true);
			input = new BufferedReader(new InputStreamReader(csock.getInputStream()));
			enter.setEnabled(true);
			
			do {
				try {
					message = input.readLine();
					display.append("\n" + message);
					display.setCaretPosition(display.getText().length());
				}catch(Exception e) {
			}
			}while (!message.contains("잘 있어"));
			
			display.append("\n사용자가 연결 종료\n");
			display.setCaretPosition(display.getText().length());
			enter.setEnabled(false);
			output.close();
			input.close();
			csock.close();
			
			
		}catch(IOException io){
		
		} 
		
	}

}
