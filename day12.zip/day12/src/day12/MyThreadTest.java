package day12;

class MyThread extends Thread{
	@Override
	public void run() {
		for(int i=10; i>=0; i--) {
			System.out.print(i + " ");
		}
	}
}

public class MyThreadTest {

	public static void main(String[] args) {
		
		for(int i=0; i<=9; i++) {
			System.out.println("메인스레드 " + i);
		}
		/////////////////////////////////////////
		Thread thread = new MyThread();
		thread.start();
		/////////////////////////////////////////

	}

}
