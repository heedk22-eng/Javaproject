package day02;

import java.util.Scanner;
public class mini2 {

	public static void main(String[] args) {
		
		double F;
		double C;
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("화씨온도를 입력하시오: ");
		F = scan.nextDouble();
		C = 5.0/9.0 * (F-32.0);
		System.out.println("섭씨온도는 " + C);
		
	}

}
