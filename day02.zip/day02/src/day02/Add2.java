package day02;

import java.util.Scanner;
public class Add2 {

	public static void main(String[] args) {
		
		int num1, num2, num3;
		System.out.println("첫번째 숫자를 입력하세요: ");
		// Scanner 입력 클래스 생성하기 (참조형 사용법)
		Scanner scan = new Scanner(System.in);
		num1 = scan.nextInt();
		System.out.println("두번째 숫자를 입력하세요: ");
		num2 = scan.nextInt();
		
		//num3 = num1+num2;	
		//System.out.println("두 정수의 합: " + num3);
		
		//num3 = num1-num2;	
		//System.out.println("두 정수의 차: " + num3);
		
		//num3 = num1*num2;	
		//System.out.println("두 정수의 곱: " + num3);
		
		num3 = num1/num2;	
		System.out.println("두 정수의 나누기: " + num3);
		

	}

}
