package day02;

import java.util.Scanner;
public class grad {

	public static void main(String[] args) {
		int s;
		
		System.out.println("성적을 입력하시오: ");
		Scanner scan = new Scanner(System.in);
		s = scan.nextInt();
		
		if(s>=90) {
			System.out.println("A");
		}else if(s>=80) {
			System.out.println("B");
		}else if(s>=70) {
			System.out.println("C");
		}else if(s>=60) {
			System.out.println("D");
		}else {
			System.out.println("F");
		}

	}

}
