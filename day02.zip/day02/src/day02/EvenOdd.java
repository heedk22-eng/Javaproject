package day02;

import java.util.Scanner;
public class EvenOdd {

	// 짝수 홀수 판단하는 조건문 이용하기
	public static void main(String[] args) {
		
		int num;
		System.out.println("숫자를 입력하시오: ");
		Scanner scan = new Scanner(System.in);
		num = scan.nextInt();
		
		//
		if(num % 2 == 0 ) {
			System.out.println("짝수");
		}else {
			System.out.println("홀수");
		}
		
	}

}
