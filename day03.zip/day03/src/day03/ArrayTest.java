package day03;

public class ArrayTest {

	public static void main(String[] args) {
		// 1차원 배열 선언
		int[] s;
		// 배열 초기화
		s = new int[10];
		// 배열 초기화2
		int[] s2 = {10, 20, 30, 40, 50};
		// for 반복문 값 출력하기
		int total = 0;
		
		for(int i=0; i<5; i++) {
			total = total + s2[i];		
		}
		System.out.println("s2배열에 있는 값의 총합: "+total);

	}

}
