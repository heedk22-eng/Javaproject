package day03;

import java.util.Scanner;
public class StringSwitch {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		int month;
		System.out.println("월의 이름을 입력하시오: ");
		
		month = scan.nextInt();
		String bwungi = "";
		
		switch (month) {
		case 1:
		case 2:
		case 3:
			bwungi = "1분기";
			break;
		case 4:
		case 5:
		case 6:
			bwungi = "2분기";
			break;
		case 7:
		case 8:
		case 9:
			bwungi = "3분기";
			break;
		case 10:
		case 11:
		case 12:
			bwungi = "4분기";
			break;
			
		}
		System.out.println(bwungi);

	}

}
