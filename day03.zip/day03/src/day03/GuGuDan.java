package day03;

import java.util.Scanner;
public class GuGuDan {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		int n = 2;
		
		//System.out.println("구구단 중에서 출력하고 싶은 단을 입력하시오: ");
		//n = scan.nextInt();
		int i = 1;
		while(n <= 9) {
			//System.out.println(n);
			
			while(i <= 9) {
				System.out.println(n + "*" + i + "=" + n * i);
				i++;
			}
			i = 1;
			n++;	
		}

	}

}
