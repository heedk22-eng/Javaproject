package day03;

import java.util.Scanner;
public class Grade2 {

	public static void main(String[] args) {
		int score, number;
		char grade;
		
		System.out.println("성적을 입력하시오: ");
		Scanner scan = new Scanner(System.in);
		score = scan.nextInt();
		number = score / 10;
		
		switch(number) {
		case 10:
		case 9:
			grade = 'A';
			break;
		case 8:
			grade = 'A';
			break;
		case 7:
			grade = 'A';
			break;
		case 6:
			grade = 'A';
			break;
		default:
			grade = 'F';
			break;
		
		}
		System.out.println("학점: " + grade);

	}

}
