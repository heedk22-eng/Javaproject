package day03;


public class ForTest2 {
	public static void main(String[] args) {
		int i;
		int sum;
		sum = 0;
		for(i=0; i<101; i++) {
			sum = sum+i;
			System.out.println(i + "=" + sum);
			
			
		}
		

	}
}
