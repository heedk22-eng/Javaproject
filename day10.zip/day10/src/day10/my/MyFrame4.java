package day10.my;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class MyFrame4 extends JFrame {
	int x, y;

	class MyPanel extends JPanel {
		
		public MyPanel() {
			addMouseListener(new MouseAdapter() {
				public void mousePressed(MouseEvent e) {
				x = e.getX();
				y = e.getY();
				repaint();
				}
			});
		}// MyPanel() 생성자
		
		protected void paintComponent(Graphics g) { 
			super.paintComponent(g);	
			g.setColor(Color.YELLOW);
			g.fillOval(x, y, 100, 100);
		}
	}

	public MyFrame4() {
		setTitle("Basic Painting");
		setSize(600, 500);
		add(new MyPanel());
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	public static void main(String[] args) {
		MyFrame4 f = new MyFrame4();
	}
}
